<?php 
    include("dbconfig.php");
?>
<?php
  session_start();

  if($_SESSION['name']=='')
  {
     header('location:reg.php');
  }

 ?>

<?php
	//getting data from registration table.
	
	$uid=$_SESSION["id"];

	$sql2=mysqli_query($con,"select * from registration where usr_id='$uid'");
	while($row3=mysqli_fetch_array($sql2)){

		$db_password=$row3['password'];
		$get_email=$row3['email'];


		$get_im=$row3['image'];
		$get_cover_pic=$row3['cover_pic'];
        $get_name=$row3['name'];
        $get_street=$row3['street'];
        $get_state=$row3['state'];
        $get_post=$row3['post'];
        $get_job=$row3['job'];
        $get_country=$row3['country'];
        $get_city=$row3['state'];
        $get_fb=$row3['facebook'];
        $get_google_plus=$row3['google_plus'];
        $get_youtube=$row3['youtube'];
        $get_project=$row3['project'];
        $get_experience=$row3['experience'];
        $get_skill=$row3['skill'];
        $get_about=$row3['about'];
        $get_phone=$row3['phone'];
        $get_blood=$row3['blood'];
        $get_java=$row3['java'];
        $get_c=$row3['c'];
        $get_c_sharp=$row3['c_sharp'];
        $get_c_plus=$row3['c_plus'];
        $get_php=$row3['php'];
        $get_html=$row3['html'];
        $get_python=$row3['python'];
        $get_css=$row3['css'];
        $get_graphic_design=$row3['graphics_design'];
        $get_photoshop=$row3['photoshop'];
											
													  
	}	
		//data from education table
		$sql_education=mysqli_query($con,"select * from education where user_id_e='$uid'");
		while ($row4=mysqli_fetch_array($sql_education)) {
			$get_ssc_school=$row4['ssc_school'];
			$get_ssc_gpa=$row4['ssc_gpa'];
			$get_ssc_session=$row4['ssc_session'];
			$get_hsc_school=$row4['hsc_school'];
			$get_hsc_gpa=$row4['hsc_gpa'];
			$get_hsc_session=$row4['hsc_session'];
			$get_undergraduate_university=$row4['undergraduate_university'];
			$get_undergraduate_degree=$row4['undergraduate_degree'];
			$get_undergraduate_gpa=$row4['undergraduate_gpa'];
			$get_undergraduate_session=$row4['undergraduate_session'];
			$get_postgraduate_university=$row4['postgraduate_university'];
			$get_postgraduate_degree=$row4['postgraduate_degree'];
			$get_postgraduate_gpa=$row4['postgraduate_gpa'];
			$get_postgraduate_session=$row4['postgraduate_session'];

			$get_ssc_group=$row4['ssc_group'];
			$get_ssc_board=$row4['ssc_board'];
			$get_hsc_group=$row4['hsc_group'];
			$get_hsc_board=$row4['hsc_board'];
		}

		//data from Job_Experience Table
		$sql_job=mysqli_query($con,"select * from jexperience where user_id_job='$uid'");
		while ($row5=mysqli_fetch_array($sql_job)){
			$get_1st_work_place=$row5['1st_work_place'];
			$get_1st_designation=$row5['1st_designation'];
			$get_1st_session=$row5['1st_session'];
			$get_2nd_work_place=$row5['2nd_work_place'];
			$get_2nd_designation=$row5['2nd_designation'];
			$get_2nd_session=$row5['2nd_session'];
			$get_interest_in=$row5['interest_in'];
		}


		//data from personal skill table
		$sql_skill=mysqli_query($con, "select * from skill where user_id_skill='$uid'");
		while($row6=mysqli_fetch_array($sql_skill)){
			$get_team_work=$row6['team_work'];
			$get_communication=$row6['communication'];
			$get_creativity=$row6['creativity'];
			$get_management=$row6['management'];
			$get_marketing=$row6['marketing'];
			$get_leadership=$row6['leadership'];
		}




?>


 <?php 
 	// For Uploading Into database

    if(isset($_POST["submit"])) {
		$uid=$_SESSION['id'];
		
		$Email=$_POST["email"];
		$Old_Password=$_POST["old_password"];
		$New_Password=$_POST["new_password"];
		$Confirm_Password=$_POST["confirm_password"];
		$Name=$_POST["name"];
		$Birthday=$_POST["birthday"];
		$Blood_Group=$_POST["blood_group"];
		$Gender=$_POST["select_gender"];
		$Street=$_POST["street"];
		$City=$_POST["city"];
		$State=$_POST["state"];
		$Country=$_POST["select_country"];
		$Post=$_POST["post"];
		$Project=$_POST["project"];
		$Experience=$_POST["experience"];
		$Job=$_POST["job"];
		$Java=$_POST["java"];
		$C=$_POST["c"];
		$C_Plus=$_POST["c_plus"];
		$C_Sharp=$_POST["c_sharp"];
		$Python=$_POST["python"];
		$Php=$_POST["php"];
		$HTML=$_POST["html"];
		$CSS=$_POST["css"];
		$Photoshop=$_POST["photoshop"];
		$Graphics_Design=$_POST["graphic_design"];
		$Facebook=$_POST["facebook"];
		$Google_Plus=$_POST["google_plus"];
		$Youtube=$_POST["youtube"];
		$Phone=$_POST["phone"];
		$About=$_POST["about"];


		//Data For Education Table

		$SSC_School=$_POST["ssc_school"];
		$SSC_Gpa=$_POST["ssc_gpa"];
		$SSC_Session=$_POST["ssc_session"];
		$SSC_Board=$_POST["ssc_board"];
		$SSC_Group=$_POST["ssc_group"];
		$HSC_School=$_POST["hsc_school"];
		$HSC_Gpa=$_POST["hsc_gpa"];
		$HSC_Session=$_POST["hsc_session"];
		$HSC_Board=$_POST["hsc_board"];
		$HSC_Group=$_POST["hsc_group"];
		$Undergraduate_University=$_POST["undergraduate_university_name"];
		$Undergraduate_Degree=$_POST["undergraduate_degree"];
		$Undergraduate_Gpa=$_POST["undergraduate_gpa"];
		$Undergraduate_Session=$_POST["undergraduate_session"];
		$Postgraduate_University=$_POST["postgraduate_university_name"];
		$Postgraduate_Degree=$_POST["postgraduate_degree"];
		$Postgraduate_Gpa=$_POST["postgraduate_gpa"];
		$Postgraduate_Session=$_POST["postgraduate_session"];

		//Data for Job_Experience Table

		$Work_1=$_POST["1st_work"];
		$Designation_1=$_POST["1st_designation"];
		$Session_1=$_POST["1st_session"];
		$Work_2=$_POST["2nd_work"];
		$Designation_2=$_POST["2nd_designation"];
		$Session_2=$_POST["2nd_session"];
		$Interest_IN=$_POST["interest_in"];

		//Data for Personal Skill

		$Communication=$_POST['communication'];
		$Team_work=$_POST['team_work'];
		$Creativity=$_POST['creativity'];
		$Leadership=$_POST['leadership'];
		$Management=$_POST['management'];
		$Marketing=$_POST['marketing'];


				//Image Upload Stuff
				$Profile_Pic=$_FILES['profile_pic']['name'];
				$Profile_Pic_Temp_Dir=$_FILES['profile_pic']['tmp_name'];
				$Profile_Pic_Size=$_FILES["profile_pic"]["size"];

				$Cover_Pic=$_FILES["cover_pic"]["name"];
				$Cover_Pic_Temp_Dir=$_FILES["cover_pic"]["tmp_name"];
				$Cover_Pic_Size=$_FILES["cover_pic"]["size"];
		

				$Profile_Pic_Path='user_images/';
				$Cover_Pic_Path='user_images/';
				$Profile_Ext = strtolower(pathinfo($Profile_Pic,PATHINFO_EXTENSION));
				$Cover_Ext = strtolower(pathinfo($Cover_Pic,PATHINFO_EXTENSION));
				$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
				$Profile_picture = rand(1000,1000000).".".$Profile_Ext;
				$Cover_picture = rand(1000,1000000).".".$Cover_Ext;
				
				if(in_array($Profile_Ext, $valid_extensions)){
					if($Profile_Pic_Size < 5000000){
					unlink($Profile_Pic_Path.$get_im);
					move_uploaded_file($Profile_Pic_Temp_Dir,$Profile_Pic_Path.$Profile_picture);
					}
					else{
						$errMSG = "Sorry, your file is too large it should be less then 5MB";
					}
				}
				else{
					$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
				}
					
				if(in_array($Cover_Ext, $valid_extensions)){
					if($Cover_Pic_Size < 5000000){
					unlink($Cover_Pic_Path.$get_im);
					move_uploaded_file($Cover_Pic_Temp_Dir,$Cover_Pic_Path.$Cover_picture);
					}
					else{
						$errMSG = "Sorry, your file is too large it should be less then 5MB";
					}
				}
				else{
					$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
				}
			
			


		
		
		$insert= mysqli_query($con,"UPDATE registration SET name='".$Name."', image='".$Profile_picture."',cover_pic='".$Cover_picture."', birthday='".$Birthday."', gender ='".$Gender."', street ='".$Street."', city ='".$City."', state ='".$State."', country ='".$Country."', java ='".$Java."',c ='".$C."', c_plus ='".$C_Plus."', c_sharp ='".$C_Sharp."', python ='".$Python."', php ='".$Php."', html ='".$HTML."', css ='".$CSS."', photoshop ='".$Photoshop."', graphics_design ='".$Graphics_Design."', facebook ='".$Facebook."', google_plus ='".$Google_Plus."', youtube ='".$Youtube."', project ='".$Project."', experience ='".$Experience."',job='".$Job."', about ='".$About."', phone ='".$Phone."', blood ='".$Blood_Group."' WHERE usr_id='".$uid."';");
		
		$insert_job_experience= mysqli_query($con,"INSERT INTO jexperience (user_id_job) values ('".$uid."');");
		$update_job_experience=mysqli_query($con, "UPDATE jexperience SET 1st_work_place='".$Work_1."', 1st_designation='".$Designation_1."', 1st_session='".$Session_1."', 2nd_work_place='".$Work_2."', 2nd_designation='".$Designation_2."', 2nd_session='".$Session_2."', interest_in='".$Interest_IN."' WHERE user_id_job='".$uid."'");

		$insert_skill=mysqli_query($con, "INSERT INTO skill (user_id_skill) values('".$uid."');");
		$update_skill=mysqli_query($con, "UPDATE skill SET team_work='".$Team_work."', communication='".$Communication."', creativity='".$Creativity."', leadership='".$Leadership."', management='".$Management."', marketing='".$Marketing."' WHERE user_id_skill='".$uid."'");
		
		$insert_education= mysqli_query($con,"INSERT INTO education (user_id_e) values ('".$uid."');");
		$update_education= mysqli_query($con,"UPDATE education SET ssc_board='".$SSC_Board."', ssc_group='".$SSC_Group."', hsc_board='".$HSC_Board."', hsc_group='".$HSC_Group."', ssc_school='".$SSC_School."',ssc_gpa='".$SSC_Gpa."',ssc_session='".$SSC_Session."', hsc_school='".$HSC_School."', hsc_gpa='".$HSC_Gpa."', hsc_session='".$HSC_Session."',undergraduate_university='".$Undergraduate_University."', undergraduate_degree='".$Undergraduate_Degree."', undergraduate_gpa='".$Undergraduate_Gpa."', undergraduate_session='".$Undergraduate_Session."', postgraduate_university='".$Postgraduate_University."', postgraduate_degree='".$Postgraduate_Degree."', postgraduate_gpa='".$Postgraduate_Gpa."', postgraduate_session='".$Postgraduate_Session."' WHERE user_id_e='".$uid."'");
		
		//$insert= mysqli_query($con,"UPDATE registration SET (name,image,cover_pic, email, birthday , gender , street , city , state, country , java ,c , c_plus , c_sharp , python , php , html , css, photoshop , graphics_design , facebook , google_plus, youtube, project , experience , about , phone , blood) values('$Name', '$Profile_Pic', '$Cover_Pic', '$Email', '$Birthday', '$Gender', '$Street', '$City', '$State', '$Country', '$Java', '$C', 'C_Plus', '$C_Sharp', '$Python', '$Php', '$HTML', '$CSS', '$Photoshop', '$Graphics_Design', '$Facebook', '$Google_Plus', '$Youtube', '$Project', '$Experience', '$About', '$Phone', '$Blood_Group') WHERE usr_id='".$uid."'");
		
		if($insert || $insert_education || $update_education||$insert_job_experience||$update_job_experience||$insert_skill||$update_skill){
			
					echo '<script>alert("Profile Update successfully..");</script>';
					
		
					
		}

		
		//Form Validation Conditions
		/*
		if ($Email=="") {
			$error[] = 'Please Enter Mail Address';
		}
		else if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
			$error[] = 'Please Enter Valid Mail Address';
		}
		else if ($Password=="") {
			$error[]='Input Password';
		}
		else if ($Confirm_Password=="") {
			$error[]='Input Confirm Password';
		}
		else if ($Password != $Confirm_Password) {
			$error[]='Password are not Matched';
		}
		else if ($Name=="") {
			$error[]='Input Name';
		}
		else if ($Birthday=="") {
			$error[]='Input Birthday';
		}
		else if ($Blood_Group=="") {
			$error[]='Input Blood_Group';
		}
		else if ($Gender=="") {
			$error[]='Input Gender';
		}
		else if ($Street=="") {
			$error[]='Input Street';
		}
		else if ($City=="") {
			$error[]='Input City';
		}
		else if ($State=="") {
			$error[]='Input State';
		}
		else if ($Country=="") {
			$error[]='Input Country';
		}
		else if ($Project=="") {
			$error[]='Input Projects that you have done!';
		}
		else if ($Experience=="") {
			$error[]='Input Experience';
		}
		else if ($Java=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($C=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($C_Plus=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($C_Sharp) {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($Python=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($Php=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($HTML=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($CSS=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($Photoshop=="") {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($Graphics_Design) {
			$error[]='Input Your Skill in Integer (0~100)';
		}
		else if ($Facebook=='') {
			$error[]='Input Your Facebook Link';
		}
		else if ($Google_Plus=="") {
			$error[]='Input Your Google+ Link';
		}
		else if ($Youtube=="") {
			$error[]='Input Your Youtube Link';
		}
		else if ($Phone=="") {
			$error[]='Input Your Phone number';
		}
		else if ($About=="") {
			$error[]='Tell Something about You!';
		}
		else if ($Cover_Pic=="") {
			$error[]='Please Select Cover Picture';
		}
		else if ($Profile_Pic=="") {
			$error[]='Please Select Profile Picture';
		}
		else if($Profile_Pic_Type=="application/pdf" || $Profile_Pic_Type=="application/pdf" || $Profile_Pic_Type=="application/x-zip-compressed")	{
		$error[] = "this type of file does not supported !";
		echo '<script>alert("this type of file does not supported !");</script>';	
		}
		else if($Cover_Pic_Type=="application/pdf" || $Cover_Pic_Type=="application/pdf" || $Cover_Pic_Type=="application/x-zip-compressed")	{
		$error[] = "this type of file does not supported !";
		echo '<script>alert("this type of file does not supported !");</script>';	
		}

		else{

			


		}
		*/

}

?>





<?php
function timeAgo($time_ago){

			$time_ago = strtotime($time_ago);
			$cur_time   = time();
			$time_elapsed   = $cur_time - $time_ago;
			$seconds    = $time_elapsed ;
			$minutes    = round($time_elapsed / 60 );
			$hours      = round($time_elapsed / 3600);
			$days       = round($time_elapsed / 86400 );
			$weeks      = round($time_elapsed / 604800);
			$months     = round($time_elapsed / 2600640 );
			$years      = round($time_elapsed / 31207680 );
			// Seconds
			if($seconds <= 60){
			    return "just now";
			}
			//Minutes
			else if($minutes <=60){
			    if($minutes==1){
			        return "one minute ago";
			    }
			    else{
			        return "$minutes minutes ago";
			    }
			}
			//Hours
			else if($hours <=24){
			    if($hours==1){
			        return "an hour ago";
			    }else{
			        return "$hours hrs ago";
			    }
			}
			//Days
			else if($days <= 7){
			    if($days==1){
			        return "yesterday";
			    }else{
			        return "$days days ago";
			    }
			}
			//Weeks
			else if($weeks <= 4.3){
			    if($weeks==1){
			        return "a week ago";
			    }else{
			        return "$weeks weeks ago";
			    }
			}
			//Months
			else if($months <=12){
			    if($months==1){
			        return "a month ago";
			    }else{
			        return "$months months ago";
			    }
			}
			//Years
			else{
			    if($years==1){
			        return "one year ago";
			    }else{
			        return "$years years ago";
			    }
			}
		} 
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Profile Update</title>


    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="user.php">
                        <!-- Logo icon -->
                        <b><img src="images/logo.png" alt="homepage" class="dark-logo" /></b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span><img src="images/logo-text.png" alt="homepage" class="dark-logo" /></span>
                    </a>
                </div>
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item m-l-10"> <a class="nav-link sidebartoggler hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <!-- Messages -->
                        <li class="nav-item dropdown mega-dropdown"> <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-th-large"></i></a>
                            <div class="dropdown-menu animated zoomIn">
                                <ul class="mega-dropdown-menu row">


                                    <li class="col-lg-3  m-b-30">
                                        <h4 class="m-b-20">CONTACT US</h4>
                                        <!-- Contact -->
                                        <form>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="exampleInputname1" placeholder="Enter Name"> </div>
                                            <div class="form-group">
                                                <input type="email" class="form-control" placeholder="Enter email"> </div>
                                            <div class="form-group">
                                                <textarea class="form-control" id="exampleTextarea" rows="3" placeholder="Message"></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-info">Submit</button>
                                        </form>
                                    </li>
                                    <li class="col-lg-3 col-xlg-3 m-b-30">
                                        <h4 class="m-b-20">List style</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                        </ul>
                                    </li>
                                    <li class="col-lg-3 col-xlg-3 m-b-30">
                                        <h4 class="m-b-20">List style</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                        </ul>
                                    </li>
                                    <li class="col-lg-3 col-xlg-3 m-b-30">
                                        <h4 class="m-b-20">List style</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">

                        <!-- Search -->
                        <li class="nav-item hidden-sm-down search-box"> <a class="nav-link hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-search"></i></a>
                            <form class="app-search">
                                <input type="text" class="form-control" placeholder="Search here"> <a class="srh-btn"><i class="ti-close"></i></a> </form>
                        </li>
                        <!-- Comment -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-bell"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated zoomIn">
                                <ul>
                                    <li>
                                        <div class="drop-title">Notifications</div>
                                    </li>
                                    <li>
                                        <div class="message-center">
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-danger btn-circle m-r-10"><i class="fa fa-link"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is title</h5> <span class="mail-desc">Just see the my new admin!</span> <span class="time">9:30 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-success btn-circle m-r-10"><i class="ti-calendar"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is another title</h5> <span class="mail-desc">Just a reminder that you have event</span> <span class="time">9:10 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-info btn-circle m-r-10"><i class="ti-settings"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is title</h5> <span class="mail-desc">You can customize this template as you want</span> <span class="time">9:08 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-primary btn-circle m-r-10"><i class="ti-user"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is another title</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:02 AM</span>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> <strong>Check all notifications</strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Comment -->
                        <!-- Messages -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-envelope"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated zoomIn" aria-labelledby="2">
                                <ul>
                                    <li>
                                        <div class="drop-title">You have 4 new messages</div>
                                    </li>
                                    <li>
                                        <div class="message-center">
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/5.jpg" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>Michael Qin</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:30 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/2.jpg" alt="user" class="img-circle"> <span class="profile-status busy pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>John Doe</h5> <span class="mail-desc">I've sung a song! See you at</span> <span class="time">9:10 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/3.jpg" alt="user" class="img-circle"> <span class="profile-status away pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>Mr. John</h5> <span class="mail-desc">I am a singer!</span> <span class="time">9:08 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/4.jpg" alt="user" class="img-circle"> <span class="profile-status offline pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>Michael Qin</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:02 AM</span>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> <strong>See all e-Mails</strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                        <!-- Profile -->
                        <li class="nav-item dropdown">
							<?php 
								echo '<a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="user_images/'.$get_im.'" alt="user" class="profile-pic" /></a>';
								echo '';
							 
							?>
						
						
                              <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">
                                    <li><a href="profile.php"><i class="ti-user"></i> Profile</a></li>
                                    <li><a href="#"><i class="ti-wallet"></i> Balance</a></li>
                                    <li><a href="#"><i class="ti-email"></i> Inbox</a></li>
                                    <li><a href="profile_update.php"><i class="ti-settings"></i> Settings</a></li>
                                    <li><a href="logout1.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard <span class="label label-rouded label-primary pull-right">2</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="user.php">Home </a></li>
                                <li><a href="notification.php">Notification </a></li>
                            </ul>
                        </li>
						
						<li> <a href="profile.php" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">Profile</span></a></li>
						<li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-briefcase"></i><span class="hide-menu">Job Post <span class="label label-rouded label-primary pull-right">3</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="my_task.php">My Post</a></li>
                                <li><a href="user.php">Recent Posts </a></li>
                                <li><a href="bid_post.php">Bid a Job </a></li>
                            </ul>
                        </li>
						<li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-cogs"></i><span class="hide-menu">Settings <span class="label label-rouded label-primary pull-right">2</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="profile_update.php">Profile update </a></li>
								<li><a href="change_password.php">Change Password </a></li>
                            </ul>
                        </li>
						
                        <li class="nav-label">Apps</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Email</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="email-compose.html">Compose</a></li>
                                <li><a href="email-read.html">Read</a></li>
                                <li><a href="email-inbox.html">Inbox</a></li>
                            </ul>
                        </li>

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h2 class="text-primary">Settings</h2> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
						<?php echo '<li class="breadcrumb-item active">'.$get_name.'</li>';?>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Settings</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Profile Update</a></li>
						
                        
                    </ol>
                </div>
            </div>
			
            <!-- End Bread crumb -->
            <!-- Container fluid  -->

			<div class="container-fluid">
					<div class="row bg-white m-l-0 m-r-0 box-shadow ">
					<div class="col-lg-12">
                        <div class="card card-outline-primary">
                            <div class="card-header">
                                <h3 class="m-b-0 text-white"><i class="fa fa-address-card-o f-s-25 color-muted"></i> Profile Update</h3>
                            </div>
                            <div class="card-body">
                                <form method="post" action="profile_update.php" enctype="multipart/form-data">
                                    <div class="form-body">
                                        <!--/row-->
                                        <i class=></i>
                                       
                                 
                                        <h3 class="box-title m-t-40"><i class="fa fa-wrench f-s-25 color-primary"></i> Profile Settings</h3>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <div class="form-group">
                                                    <label><i class="fa fa-user-o f-s-15 color-primary"></i> Name</label>
                                                    <input type="text" name="name"class="form-control" placeholder="<?php if ($get_name==""){echo 'Update Name';} else echo''.$get_name.'';?>" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label><i class="fa fa-heart-o f-s-15 color-primary"></i> Birthday</label>
                                                    <input type="Date" class="form-control" name="birthday" required>
                                                </div>
                                            </div>
											<div class="col-md-4">
                                                <div class="form-group">
                                                    <label><i class="fa fa-tint f-s-15 color-primary"></i> Blood Group</label>
                                                    <input type="Text" class="form-control" name="blood_group" placeholder="<?php if ($get_blood==""){echo 'Update Blood Group';} else echo''.$get_blood.'';?>">
                                                </div>
                                            </div>	
                                            <!--/span-->
                                            <div class="col-md-4">
                                                <div class="form-group has-success">
                                                    <label class="control-label"><i class="fa fa-venus-mars f-s-15 color-primary"></i> Gender</label>
                                                    <select class="form-control custom-select" name="select_gender">
                                                        <option value="male">Male</option>
                                                        <option value="female">Female</option>
                                                    </select>
                                                    <small class="form-control-feedback"> Select your gender </small> </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<hr>
                                        <!--/row-->
                                        <h3 class="box-title m-t-40"><i class="fa fa-map-o f-s-25 color-primary"></i> Address</h3>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <div class="form-group">
                                                    <label><i class="fa fa-road f-s-15 color-primary"></i> Street</label>
                                                    <input type="text" name="street" class="form-control" placeholder="<?php if ($get_street==""){echo 'Update Street Number';} else echo''.$get_street.'';?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label><i class="fa fa-building f-s-15 color-primary"></i> City</label>
                                                    <input type="text" name="city" class="form-control" placeholder="<?php if ($get_city==""){echo 'Update City';} else echo''.$get_city.'';?>" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label><i class="fa fa-ship f-s-15 color-primary"></i> State</label>
                                                    <input type="text" name="state" class="form-control" placeholder="<?php if ($get_state==""){echo 'Update State';} else echo''.$get_state.'';?>">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label><i class="fa fa-envelope f-s-15 color-primary"></i> Post Code</label>
                                                    <input type="text" name="post" class="form-control" placeholder="<?php if ($get_post==""){echo 'Update Post Code';} else echo''.$get_post.'';?>">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label><i class="fa fa-flag f-s-15 color-primary"></i> Country</label>
                                                    <select class="form-control custom-select" name="select_country">
                                                        <option>Select your Country</option>
                                                        <option value="Bangladesh">Bangladesh</option>
                                                        <option value="India">India</option>
                                                        <option value="Srilanka">Srilanka</option>
                                                        <option value="usa">USA</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--Personal Experience-->
                                        <hr>
										<h3 class="box-title m-t-40">Personal Experience</h3>
										<hr>
										<div class="row">
											<div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Current Work Place</label>
                                                    <input type="text" name="job" class="form-control" placeholder="<?php if ($get_job==""){echo 'Update Work Place';} else echo''.$get_job.'';?>" >
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Project</label>
                                                    <input type="text" name="project" class="form-control" placeholder="<?php if ($get_project==""){echo 'Update Project';} else echo''.$get_project.'';?>" >
                                                </div>
                                            </div>
											<div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Experience</label>
                                                    <input type="text" name="experience" class="form-control" placeholder="<?php if ($get_experience==""){echo 'Update Experience';} else echo''.$get_experience.'';?>" >
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Interest In</label>
                                                    <input type="text" name="interest_in" class="form-control" placeholder="<?php if ($get_interest_in==""){echo 'Update Experience';} else echo''.$get_interest_in.'';?>" >
                                                </div>
                                            </div>
                                        </div>
                                        <!--Job Experience-->
										<hr>
										<h3 class="box-title m-t-40">Job Experience</h3>
										<hr>
										<div class="row">
											<div class="col-md-4">
                                                <div class="form-group">
                                                    <label>1st Work Place</label>
                                                    <input type="text" name="1st_work" class="form-control" placeholder="<?php if ($get_1st_work_place==""){echo 'Update Work Place';} else echo''.$get_1st_work_place.'';?>" >
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Designation</label>
                                                    <input type="text" name="1st_designation" class="form-control" placeholder="<?php if ($get_1st_designation==""){echo 'Update Project';} else echo''.$get_1st_designation.'';?>" >
                                                </div>
                                            </div>
											<div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Session</label>
                                                    <input type="text" name="1st_session" class="form-control" placeholder="<?php if ($get_1st_session==""){echo 'Update Experience';} else echo''.$get_1st_session.'';?>" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
											<div class="col-md-4">
                                                <div class="form-group">
                                                    <label>2nd Work Place</label>
                                                    <input type="text" name="2nd_work" class="form-control" placeholder="<?php if ($get_2nd_work_place==""){echo 'Update Work Place';} else echo''.$get_2nd_work_place.'';?>" >
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Designation</label>
                                                    <input type="text" name="2nd_designation" class="form-control" placeholder="<?php if ($get_2nd_designation==""){echo 'Update Project';} else echo''.$get_2nd_designation.'';?>" >
                                                </div>
                                            </div>
											<div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Session</label>
                                                    <input type="text" name="2nd_session" class="form-control" placeholder="<?php if ($get_2nd_session==""){echo 'Update Experience';} else echo''.$get_2nd_session.'';?>" >
                                                </div>
                                            </div>
                                        </div>
                                        <hr>

                                        <h3 class="box-title m-t-40">Education</h3>
										<hr>
										<div class="row">
											<div class="col-md-3">
                                                <div class="form-group">
                                                    <label>S.S.C.</label>
                                                    <input type="text" name="ssc_school" class="form-control" placeholder="<?php if ($get_ssc_school==""){echo 'Update School';} else echo''.$get_ssc_school.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. School Name </small>
                                                </div>
                                            </div>
                                              <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Board<br></label>
                                                    <input type="text" name="ssc_board" class="form-control" placeholder="<?php if ($get_ssc_board==""){echo 'Update Session';} else echo''.$get_ssc_board.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. Board </small>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Session<br></label>
                                                    <input type="text" name="ssc_session" class="form-control" placeholder="<?php if ($get_ssc_session==""){echo 'Update Session';} else echo''.$get_ssc_session.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. Session</small>
                                                </div>
                                            </div>
                                          
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Group<br></label>
                                                    <input type="text" name="ssc_group" class="form-control" placeholder="<?php if ($get_ssc_group==""){echo 'Update Session';} else echo''.$get_ssc_group.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. Group </small>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>GPA<br></label>
                                                    <input type="text" name="ssc_gpa" class="form-control" placeholder="<?php if ($get_ssc_gpa==""){echo 'Update GPA';} else echo''.$get_ssc_gpa.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. GPA </small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
											<div class="col-md-3">
                                                <div class="form-group">
                                                    <label>H.S.C.</label>
                                                    <input type="text" name="hsc_school" class="form-control" placeholder="<?php if ($get_hsc_school==""){echo 'Update College';} else echo''.$get_hsc_school.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your H.S.C. School Name </small>
                                                </div>
                                            </div>
                                              <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Board<br></label>
                                                    <input type="text" name="hsc_board" class="form-control" placeholder="<?php if ($get_hsc_board==""){echo 'Update Session';} else echo''.$get_hsc_board.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. Board </small>
                                                </div>
                                            </div>
                                           
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Session<br></label>
                                                    <input type="text" name="hsc_session" class="form-control" placeholder="<?php if ($get_hsc_session==""){echo 'Update Session';} else echo''.$get_hsc_session.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your H.S.C. Session </small>
                                                </div>
                                            </div>
                                          
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Group<br></label>
                                                    <input type="text" name="hsc_group" class="form-control" placeholder="<?php if ($get_hsc_group==""){echo 'Update Session';} else echo''.$get_hsc_group.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your S.S.C. Group </small>
                                                </div>
                                            </div>
                                             <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>GPA<br></label>
                                                    <input type="text" name="hsc_gpa" class="form-control" placeholder="<?php if ($get_hsc_gpa==""){echo 'Update GPA';} else echo''.$get_hsc_gpa.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your H.S.C. GPA </small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
											<div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Undergraduate</label>
                                                    <input type="text" name="undergraduate_university_name" class="form-control" placeholder="<?php if ($get_undergraduate_university==""){echo 'Update University';} else echo''.$get_undergraduate_university.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Undergraduate Institute Name </small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Degree<br></label>
                                                    <input type="text" name="undergraduate_degree" class="form-control" placeholder="<?php if ($get_undergraduate_degree==""){echo 'Update Degree';} else echo''.$get_undergraduate_degree.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Undergraduate Degree </small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>CGPA<br></label>
                                                    <input type="text" name="undergraduate_gpa" class="form-control" placeholder="<?php if ($get_undergraduate_gpa==""){echo 'Update CGPA';} else echo''.$get_undergraduate_gpa.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Undergraduate CGPA </small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Session<br></label>
                                                    <input type="text" name="undergraduate_session" class="form-control" placeholder="<?php if ($get_undergraduate_session==""){echo 'Update Session';} else echo''.$get_undergraduate_session.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Undergraduate Session Year </small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
											<div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Postgraduate</label>
                                                    <input type="text" name="postgraduate_university_name" class="form-control" placeholder="<?php if ($get_postgraduate_university==""){echo 'Update University';} else echo''.$get_postgraduate_university.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Postgraduate Institute Name </small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Degree<br></label>
                                                    <input type="text" name="postgraduate_degree" class="form-control" placeholder="<?php if ($get_postgraduate_degree==""){echo 'Update Degree';} else echo''.$get_postgraduate_degree.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Postraduate Degree </small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>CGPA<br></label>
                                                    <input type="text" name="postgraduate_gpa" class="form-control" placeholder="<?php if ($get_postgraduate_gpa==""){echo 'Update CGPA';} else echo''.$get_postgraduate_gpa.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Postgraduate CGPA </small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>Session<br></label>
                                                    <input type="text" name="postgraduate_session" class="form-control" placeholder="<?php if ($get_postgraduate_session==""){echo 'Update Session';} else echo''.$get_postgraduate_session.'';?>" >
                                                    <small class="form-control-feedback"> Insert Your Postgraduate Session Year </small>
                                                </div>
                                            </div>
                                        </div>




										<hr>
										<h3 class="box-title m-t-40">Professional Skill</h3>
										<small class="form-control-feedback"> Insert The values in integer mode (1~100) </small> </div>
										<hr>
										
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Java</label>
                                                    <input type="number" name="java" class="form-control" placeholder="<?php echo''.$get_java.'';?>%" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>C</label>
                                                    <input type="number" name="c" class="form-control" placeholder="<?php echo''.$get_c.'';?>%" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>C++</label>
                                                    <input type="number" name="c_plus" class="form-control" placeholder="<?php echo''.$get_c_plus.'';?>%" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>C#</label>
                                                    <input type="number" name="c_sharp" class="form-control" placeholder="<?php echo''.$get_c_sharp.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Python</label>
                                                    <input type="number" name="python" class="form-control" placeholder="<?php echo''.$get_python.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>PHP</label>
                                                    <input type="number" name="php" class="form-control" placeholder="<?php echo''.$get_php.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>HTML</label>
                                                    <input type="number"name="html" class="form-control" placeholder="<?php echo''.$get_html.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>CSS</label>
                                                    <input type="number" name="css" class="form-control" placeholder="<?php echo''.$get_css.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Photoshop</label>
                                                    <input type="number" name="photoshop" class="form-control" placeholder="<?php echo''.$get_photoshop.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Graphics Design</label>
                                                    <input type="number" name="graphic_design" class="form-control" placeholder="<?php echo''.$get_graphic_design.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>



                                        <!--Personal Skill-->
                                        <hr>
										<h3 class="box-title m-t-40">Personal Skill</h3>
										<small class="form-control-feedback"> Insert The values in integer mode (1~100) </small> </div>
										<hr>
										
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Communication</label>
                                                    <input type="number" name="communication" class="form-control" placeholder="<?php echo''.$get_communication.'';?>%" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Team Work</label>
                                                    <input type="number" name="team_work" class="form-control" placeholder="<?php echo''.$get_team_work.'';?>%" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Creativity</label>
                                                    <input type="number" name="creativity" class="form-control" placeholder="<?php echo''.$get_creativity.'';?>%" >
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Marketing</label>
                                                    <input type="number" name="marketing" class="form-control" placeholder="<?php echo''.$get_marketing.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Management</label>
                                                    <input type="number" name="management" class="form-control" placeholder="<?php echo''.$get_management.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Leadership</label>
                                                    <input type="number" name="leadership" class="form-control" placeholder="<?php echo''.$get_leadership.'';?>%">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										
                                        <!--Personal Skill-End-->
										<hr>
										<h3 class="box-title m-t-40">Contact & About</h3>
										<hr>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Facebook</label>
                                                    <input type="text" name="facebook" class="form-control" placeholder="<?php if ($get_fb==""){echo 'Update Facebook Profile Link';} else echo''.$get_fb.'';?>">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Google+</label>
                                                    <input type="text" name="google_plus" class="form-control" placeholder="<?php if ($get_google_plus==""){echo 'Update Google+ Profile Link';} else echo''.$get_google_plus.'';?>">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Youtube</label>
                                                    <input type="text"name="youtube" class="form-control" placeholder="<?php if ($get_youtube==""){echo 'Update Youtube Link';} else echo''.$get_youtube.'';?>">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Phone No</label>
                                                    <input type="number" name="phone" class="form-control"placeholder="<?php if ($get_phone==""){echo 'Update Phone Number';} else echo''.$get_phone.'';?>">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										<div class="row">
                                            <div class="col-md-12 ">
                                                <div class="form-group">
                                                    <label>About</label>
													
                                                    <input type="text" name="about" class="form-control"placeholder="<?php if ($get_about==""){echo 'Update About';} else echo''.$get_about.'';?>">
                                                </div>
                                            </div>
                                        </div>
										<hr>
										<h3 class="box-title m-t-40">Cover Photo and Profile Pic</h3>
										
										<hr>
										<div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Choose Cover Photo</label>
                                                    <input type="file" class="form-control" name="cover_pic">
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Choose Profile Pic</label>
                                                    <input type="file" class="form-control" name="profile_pic">
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
										
										
                                    </div>
                                    <div class="modal-footer">
										<div class="btn-group btn-group-justified" role="group" aria-label="group button">
											
											<div class="btn-group" role="group">
												<button type="submit" name="submit"  class="btn btn btn-primary" value="Post"><i class="fa fa-check"></i> Update!</button>
											</div>
										</div>
									</div>
                                </form>
                            </div>
                        </div>
					</div>
				</div>
			
			
			
			
            <!-- End Container fluid  -->
			
            <!-- footer -->
            <footer class="footer"> Spark-tech-academy© 2018 All rights reserved. Template designed by <a href="https://sparktechacademy.wordpress.com">SHAMIM HASAN</a></footer>
            <!-- End footer -->
        </div>

        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/prism.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/pignose.init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>

</html>
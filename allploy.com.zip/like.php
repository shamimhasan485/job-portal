<?php 
    include("dbconfig.php");
?>
<?php
  session_start();
  if($_SESSION['name']=='')
  {
     header('location:index.php');
  }

 ?>
 <?php
 	$Post_id=$_REQUEST["p_id"];
 	$userid=$_REQUEST["user_id"];

 	//$check_like="SELECT * userlikecount WHERE user_id_count='.$uid.'";


 	$like_sql=mysqli_query($con, "INSERT INTO likes (user_id_likes, post_id_p) VALUES ('.$userid.', '.$Post_id.');");

 	if($like_sql){
 		header('location:user.php');
 	}




 ?>
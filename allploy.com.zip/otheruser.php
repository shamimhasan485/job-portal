<?php 
    include("dbconfig.php");
?>
<?php
  session_start();

  if(!$_SESSION)
  {
     header('location:index.php');
  }

 ?>
<?php
	//getting data from registration table.
	
	$uid=$_REQUEST["userid"];
	$sql2=mysqli_query($con,"select * from registration where usr_id='$uid'");
	while($row3=mysqli_fetch_array($sql2)){

		$db_password=$row3['password'];
		$get_email=$row3['email'];


		$get_im=$row3['image'];
        $get_cover_pic=$row3['cover_pic'];
        $get_name=$row3['name'];
        $get_birthday=$row3['birthday'];
        $get_street=$row3['street'];
        $get_state=$row3['state'];
        $get_post=$row3['post'];
        $get_job=$row3['job'];
        $get_country=$row3['country'];
        $get_city=$row3['state'];
        $get_fb=$row3['facebook'];
        $get_google_plus=$row3['google_plus'];
        $get_youtube=$row3['youtube'];
        $get_project=$row3['project'];
        $get_experience=$row3['experience'];
        $get_skill=$row3['skill'];
        $get_about=$row3['about'];
        $get_phone=$row3['phone'];
        $get_blood=$row3['blood'];
        $get_java=$row3['java'];
        $get_c=$row3['c'];
        $get_c_sharp=$row3['c_sharp'];
        $get_c_plus=$row3['c_plus'];
        $get_php=$row3['php'];
        $get_html=$row3['html'];
        $get_python=$row3['python'];
        $get_css=$row3['css'];
        $get_graphic_design=$row3['graphics_design'];
        $get_photoshop=$row3['photoshop'];
													  
	}


    //data from education table
        $sql_education=mysqli_query($con,"select * from education where user_id_e='$uid'");
        while ($row4=mysqli_fetch_array($sql_education)) {
            $get_ssc_school=$row4['ssc_school'];
            $get_ssc_gpa=$row4['ssc_gpa'];
            $get_ssc_session=$row4['ssc_session'];
            $get_hsc_school=$row4['hsc_school'];
            $get_hsc_gpa=$row4['hsc_gpa'];
            $get_hsc_session=$row4['hsc_session'];
            $get_undergraduate_university=$row4['undergraduate_university'];
            $get_undergraduate_degree=$row4['undergraduate_degree'];
            $get_undergraduate_gpa=$row4['undergraduate_gpa'];
            $get_undergraduate_session=$row4['undergraduate_session'];
            $get_postgraduate_university=$row4['postgraduate_university'];
            $get_postgraduate_degree=$row4['postgraduate_degree'];
            $get_postgraduate_gpa=$row4['postgraduate_gpa'];
            $get_postgraduate_session=$row4['postgraduate_session'];

            $get_ssc_group=$row4['ssc_group'];
            $get_ssc_board=$row4['ssc_board'];
            $get_hsc_group=$row4['hsc_group'];
            $get_hsc_board=$row4['hsc_board'];
        }


        //data from Job_Experience Table
        $sql_job=mysqli_query($con,"select * from jexperience where user_id_job='$uid'");
        while ($row5=mysqli_fetch_array($sql_job)){
            $get_1st_work_place=$row5['1st_work_place'];
            $get_1st_designation=$row5['1st_designation'];
            $get_1st_session=$row5['1st_session'];
            $get_2nd_work_place=$row5['2nd_work_place'];
            $get_2nd_designation=$row5['2nd_designation'];
            $get_2nd_session=$row5['2nd_session'];
            $get_interest_in=$row5['interest_in'];
        }



        //data from personal skill table
        $sql_skill=mysqli_query($con, "select * from skill where user_id_skill='$uid'");
        while($row6=mysqli_fetch_array($sql_skill)){
            $get_team_work=$row6['team_work'];
            $get_communication=$row6['communication'];
            $get_creativity=$row6['creativity'];
            $get_management=$row6['management'];
            $get_marketing=$row6['marketing'];
            $get_leadership=$row6['leadership'];
        }



?>
<?php
function timeAgo($time_ago){

			$time_ago = strtotime($time_ago);
			$cur_time   = time();
			$time_elapsed   = $cur_time - $time_ago;
			$seconds    = $time_elapsed ;
			$minutes    = round($time_elapsed / 60 );
			$hours      = round($time_elapsed / 3600);
			$days       = round($time_elapsed / 86400 );
			$weeks      = round($time_elapsed / 604800);
			$months     = round($time_elapsed / 2600640 );
			$years      = round($time_elapsed / 31207680 );
			// Seconds
			if($seconds <= 60){
			    return "just now";
			}
			//Minutes
			else if($minutes <=60){
			    if($minutes==1){
			        return "one minute ago";
			    }
			    else{
			        return "$minutes minutes ago";
			    }
			}
			//Hours
			else if($hours <=24){
			    if($hours==1){
			        return "an hour ago";
			    }else{
			        return "$hours hrs ago";
			    }
			}
			//Days
			else if($days <= 7){
			    if($days==1){
			        return "yesterday";
			    }else{
			        return "$days days ago";
			    }
			}
			//Weeks
			else if($weeks <= 4.3){
			    if($weeks==1){
			        return "a week ago";
			    }else{
			        return "$weeks weeks ago";
			    }
			}
			//Months
			else if($months <=12){
			    if($months==1){
			        return "a month ago";
			    }else{
			        return "$months months ago";
			    }
			}
			//Years
			else{
			    if($years==1){
			        return "one year ago";
			    }else{
			        return "$years years ago";
			    }
			}
		} 
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Profile</title>


    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="user.php">
                        <!-- Logo icon -->
                        <b><img src="images/logo.png" alt="homepage" class="dark-logo" /></b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span><img src="images/logo-text.png" alt="homepage" class="dark-logo" /></span>
                    </a>
                </div>
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item m-l-10"> <a class="nav-link sidebartoggler hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <!-- Messages -->
                        <li class="nav-item dropdown mega-dropdown"> <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-th-large"></i></a>
                            <div class="dropdown-menu animated zoomIn">
                                <ul class="mega-dropdown-menu row">


                                    <li class="col-lg-3  m-b-30">
                                        <h4 class="m-b-20">CONTACT US</h4>
                                        <!-- Contact -->
                                        <form>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="exampleInputname1" placeholder="Enter Name"> </div>
                                            <div class="form-group">
                                                <input type="email" class="form-control" placeholder="Enter email"> </div>
                                            <div class="form-group">
                                                <textarea class="form-control" id="exampleTextarea" rows="3" placeholder="Message"></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-info">Submit</button>
                                        </form>
                                    </li>
                                    <li class="col-lg-3 col-xlg-3 m-b-30">
                                        <h4 class="m-b-20">List style</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                        </ul>
                                    </li>
                                    <li class="col-lg-3 col-xlg-3 m-b-30">
                                        <h4 class="m-b-20">List style</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                        </ul>
                                    </li>
                                    <li class="col-lg-3 col-xlg-3 m-b-30">
                                        <h4 class="m-b-20">List style</h4>
                                        <!-- List style -->
                                        <ul class="list-style-none">
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                            <li><a href="javascript:void(0)"><i class="fa fa-check text-success"></i> This Is Another Link</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">

                        <!-- Search -->
                        <li class="nav-item hidden-sm-down search-box"> <a class="nav-link hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-search"></i></a>
                            <form class="app-search">
                                <input type="text" class="form-control" placeholder="Search here"> <a class="srh-btn"><i class="ti-close"></i></a> </form>
                        </li>
                        <!-- Comment -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-bell"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated zoomIn">
                                <ul>
                                    <li>
                                        <div class="drop-title">Notifications</div>
                                    </li>
                                    <li>
                                        <div class="message-center">
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-danger btn-circle m-r-10"><i class="fa fa-link"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is title</h5> <span class="mail-desc">Just see the my new admin!</span> <span class="time">9:30 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-success btn-circle m-r-10"><i class="ti-calendar"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is another title</h5> <span class="mail-desc">Just a reminder that you have event</span> <span class="time">9:10 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-info btn-circle m-r-10"><i class="ti-settings"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is title</h5> <span class="mail-desc">You can customize this template as you want</span> <span class="time">9:08 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="btn btn-primary btn-circle m-r-10"><i class="ti-user"></i></div>
                                                <div class="mail-contnet">
                                                    <h5>This is another title</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:02 AM</span>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> <strong>Check all notifications</strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Comment -->
                        <!-- Messages -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-envelope"></i>
								<div class="notify"> <span class="heartbit"></span> <span class="point"></span> </div>
							</a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated zoomIn" aria-labelledby="2">
                                <ul>
                                    <li>
                                        <div class="drop-title">You have 4 new messages</div>
                                    </li>
                                    <li>
                                        <div class="message-center">
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/5.jpg" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>Michael Qin</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:30 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/2.jpg" alt="user" class="img-circle"> <span class="profile-status busy pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>John Doe</h5> <span class="mail-desc">I've sung a song! See you at</span> <span class="time">9:10 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/3.jpg" alt="user" class="img-circle"> <span class="profile-status away pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>Mr. John</h5> <span class="mail-desc">I am a singer!</span> <span class="time">9:08 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="#">
                                                <div class="user-img"> <img src="images/users/4.jpg" alt="user" class="img-circle"> <span class="profile-status offline pull-right"></span> </div>
                                                <div class="mail-contnet">
                                                    <h5>Michael Qin</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:02 AM</span>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link text-center" href="javascript:void(0);"> <strong>See all e-Mails</strong> <i class="fa fa-angle-right"></i> </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Messages -->
                        <!-- Profile -->
                        <li class="nav-item dropdown">
							<?php echo '<a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="user_images/'.$get_im.'" alt="user" class="profile-pic" /></a>';?>
						
						
                              <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">
                                    <li><a href="profile.php"><i class="ti-user"></i> Profile</a></li>
                                    <li><a href="#"><i class="ti-wallet"></i> Balance</a></li>
                                    <li><a href="#"><i class="ti-email"></i> Inbox</a></li>
                                    <li><a href="#"><i class="ti-settings"></i> Setting</a></li>
                                    <li><a href="logout1.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard <span class="label label-rouded label-primary pull-right">2</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="user.php">Home </a></li>
                                <li><a href="notification.php">Notification </a></li>
                            </ul>
                        </li>
						
						<li> <a href="profile.php" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">Profile</span></a></li>
						<li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-briefcase"></i><span class="hide-menu">Job Post <span class="label label-rouded label-primary pull-right">3</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="my_task.php">My Post</a></li>
                                <li><a href="user.php">Recent Posts </a></li>
                                <li><a href="bid_post.php">Bid a Job </a></li>
                            </ul>
                        </li>
						<li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-cogs"></i><span class="hide-menu">Setting <span class="label label-rouded label-primary pull-right">2</span></span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="profile_update.php">Profile update </a></li>
                                <li><a href="change_password.php">Change Password </a></li>
                            </ul>
                        </li>
						
                        <li class="nav-label">Apps</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Email</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="email-compose.html">Compose</a></li>
                                <li><a href="email-read.html">Read</a></li>
                                <li><a href="email-inbox.html">Inbox</a></li>
                            </ul>
                        </li>

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Profile</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
						<?php echo '<li class="breadcrumb-item active">'.$get_name.'</li>';?>
									<li class="breadcrumb-item"><a href="javascript:void(0)">Profile</a></li>
											
							 
						
                        
                    </ol>
                </div>
            </div>
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
			<div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row">
                    <div class="col-lg-12">
					   <div class="card">
                            
									<div class="card-body "  style="repeat:norepeat; height:500px; width:100%; background:url(<?php echo 'user_images/'.$get_cover_pic.'" ';?>)" data-img-width="2000" data-img-height="1330" data-diff="300" class="img-responsive radius">
										<div class="card-two">
                                             <br><br><br><br><br><br>
											<header >
												<div class="avatar" >
													<a class="nav-link dropdown-toggle text-muted" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="user_images/<?php echo''.$get_im.'';?>" alt="user" class="profile-pic" /></a>    
												</div>
											</header>


											<?php echo'<h3><font color="white">'.$get_name.'</font></h3>';?>
											<div class="desc">
												<?php echo '<h5><font color="white">'.$get_about.'</font></h5>';?>
											</div>
											<div class="contacts ">
												<a href="<?php echo ''.$get_fb.'';?>"><i class="fa fa-facebook f-s-25  "></i></a>
												<a href="<?php echo ''.$get_google_plus.'';?>"><i class="fa fa-google-plus f-s-25 "></i></a>
												<a href="<?php echo ''.$get_youtube.'';?>"><i class="fa fa-youtube-play f-s-25"></i></a>
												<div class="clear"></div>
											</div>
										</div>
									</div>
								</div>
						
					
					
                        
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-12">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Timeline</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Profile</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Contact With Me</a> </li>
                            </ul>
                            <!-- All-Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-body">
                                        <div class="profiletimeline">
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="images/users/avatar-1.jpg" alt="user" class="img-circle" /> </div>
                                                <div class="sl-right">
                                                    <div><a href="#" class="link">Michael Qin</a> <span class="sl-date">5 minutes ago</span>
                                                        <p>assign a new task <a href="#"> Design weblayout</a></p>
                                                        <div class="row">
                                                            <div class="col-lg-3 col-md-6 m-b-20"><img src="images/big/img1.jpg" class="img-responsive radius" /></div>
                                                            <div class="col-lg-3 col-md-6 m-b-20"><img src="images/big/img2.jpg" class="img-responsive radius" /></div>
                                                            <div class="col-lg-3 col-md-6 m-b-20"><img src="images/big/img3.jpg" class="img-responsive radius" /></div>
                                                            <div class="col-lg-3 col-md-6 m-b-20"><img src="images/big/img4.jpg" class="img-responsive radius" /></div>
                                                        </div>
                                                        <div class="like-comm"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="images/users/avatar-2.jpg" alt="user" class="img-circle" /> </div>
                                                <div class="sl-right">
                                                    <div> <a href="#" class="link">Michael Qin</a> <span class="sl-date">5 minutes ago</span>
                                                        <div class="m-t-20 row">
                                                            <div class="col-md-3 col-xs-12"><img src="images/big/img1.jpg" alt="user" class="img-responsive radius" /></div>
                                                            <div class="col-md-9 col-xs-12">
                                                                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. </p> <a href="#" class="btn btn-success"> Design weblayout</a></div>
                                                        </div>
                                                        <div class="like-comm m-t-20"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="images/users/avatar-3.jpg" alt="user" class="img-circle" /> </div>
                                                <div class="sl-right">
                                                    <div><a href="#" class="link">Michael Qin</a> <span class="sl-date">5 minutes ago</span>
                                                        <p class="m-t-10"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum.
                                                            Praesent mauris. Fusce nec tellus sed augue semper </p>
                                                    </div>
                                                    <div class="like-comm m-t-20"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="images/users/avatar-4.jpg" alt="user" class="img-circle" /> </div>
                                                <div class="sl-right">
                                                    <div><a href="#" class="link">Michael Qin</a> <span class="sl-date">5 minutes ago</span>
                                                        <blockquote class="m-t-10">
                                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt
                                                        </blockquote>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--second tab-->
                                <div class="tab-pane" id="profile" role="tabpanel">
                                <!--Profile Tab Panel-->
                                <div class="row">
                                     <!--Side bar  Column -->
                                    <div class="col-lg-4">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header f-s-25 bg-info">
                                                        <i class="fa fa-drivers-license"></i><strong class="card-title pl-2">Profile Card</strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="card-two">
                                                            <header>
                                                                <div class="avatar">
                                                                    <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="user_images/<?php echo''.$get_im.'';?>" alt="user" class="profile-pic" /></a>    
                                                                </div>
                                                            </header>
                                                            
                                                            <br><br><br><br><br>
                                                            <?php if($get_job!="")echo'<h5 class="text-sm-center"><i class="fa fa-quote-left f-s-15 color-info"></i> '.$get_job.' <i class="fa fa-quote-right f-s-15 color-info"></i><br></h5>';?>
                                                            <div class="location text-sm-center "><i class=><hr></i> </div>
                                                            <div class="location text-sm-center text-lg-center"><i class="fa fa-map-marker f-s-30 color-info"></i> </div>
                                                            <div class="location text-sm-center"><i ></i> <?php echo''.$get_street.'';?></div>
                                                            <div class="location text-sm-center"><i ></i> <?php echo''.$get_city.'';?>, <?php echo''.$get_state.'';?>, <?php echo''.$get_post.'';?></div>
                                                            <div class="location text-sm-center"><i ></i> <?php echo''.$get_country.'';?></div>
                                                        </div>
                                                        <hr>
                                                        <div class="card-text text-sm-center">
                                                            <a href="<?php echo''.$get_fb.'';?>"><i class="fa fa-facebook f-s-20  pr-1"></i></a>
                                                            <a href="<?php echo''.$get_youtube.'';?>"><i class="fa fa-youtube f-s-20  pr-1"></i></a>
                                                            <a href="<?php echo''.$get_google_plus.'';?>"><i class="fa fa-google-plus f-s-20  pr-1"></i></a>
                                                            <a href="<?php echo''.$get_fb.'';?>"><i class="fa fa-pinterest f-s-20  pr-1"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                                <!--Intro Column-->
                                                <div class="col-md-12">
                                                    <aside class="profile-nav alt">
                                                        <section class="card">
                                                            <div class="card-header bg-success">
                                                                <i class="fa fa-bullhorn f-s-25 "></i><strong class="card-title pl-2 ">Intro</strong>
                                                            </div>


                                                         <ul class="list-group list-group-flush">
                                                         <?php if ($get_ssc_school!=""){echo'<li class="list-group-item">
                                                              <a href="#"> <i class="fa fa-graduation-cap color-success"></i> Went To <b>'.$get_ssc_school.'</b> <span class="badge badge-primary pull-right"></span></a>
                                                          </li>';}?>
                                                          <?php if ($get_hsc_school!=""){echo'<li class="list-group-item">
                                                              <a href="#"> <i class="fa fa-graduation-cap color-success"></i> Went To <b>'.$get_hsc_school.'</b> <span class="badge badge-primary pull-right"></span></a>
                                                          </li>';}?>
                                                          <?php if ($get_street!=""&&$get_country!=""&&$get_state!=""){echo'<li class="list-group-item">
                                                              <a href="#"> <i class="fa fa-home color-success"></i> Lives in <b>'.$get_street.', '.$get_city.', '.$get_country.'</b> <span class="badge badge-primary pull-right"></span></a>
                                                          </li>';}?>
                                                          <?php if ($get_city!=""&&$get_country!=""){echo'<li class="list-group-item">
                                                              <a href="#"> <i class="fa fa-map color-success"></i> From <b>'.$get_city.', '.$get_country.'</b> <span class="badge badge-primary pull-right"></span></a>
                                                          </li>';}?>
                                                          <?php if ($get_project!=""){echo'<li class="list-group-item">
                                                              <a href="#"> <i class="fa fa-microchip color-success"></i> Projects <b>'.$get_project.'</b> <span class="badge badge-primary pull-right"></span></a>
                                                          </li>';}?>
                                                          <?php if ($get_phone!=""){echo'<li class="list-group-item">
                                                              <a href="#"> <i class="fa fa-phone color-success"></i> Phone <b>'.$get_phone.'</b> <span class="badge badge-primary pull-right"></span></a>
                                                          </li>';}?>
                                                          

                                                        </section>
                                                    </aside>
                                                </div>
                                                <!--intro Column End-->
                                                <!--Professional Skill Column Start-->
                                                  <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-header bg-warning">
                                                            <i class="fa fa-handshake-o f-s-25"></i><strong class="card-title pl-2">Professional Skill</strong>
                                                        </div>
                                                        <div class="card-body browser">
                                                            <br>
                                                            <p class="f-w-600">Java <span class="pull-right"><?php echo''.$get_java.'';?>%</span></p>
                                                            <div class="progress ">
                                                                <div role="progressbar" style="width: <?php echo''.$get_java.'';?>%; height:8px;" class="progress-bar bg-danger wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">C<span class="pull-right"><?php echo''.$get_c.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_c.'';?>%; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">C++<span class="pull-right"><?php echo''.$get_c_plus.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_c_plus.'';?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">C#<span class="pull-right"><?php echo''.$get_c_sharp.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_c_sharp.'';?>%; height:8px;" class="progress-bar bg-warning wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">Python<span class="pull-right"><?php echo''.$get_python.'';?>%</span></p>
                                                            <div class="progress m-b-30">
                                                                <div role="progressbar" style="width: <?php echo''.$get_python.'';?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                            <p class="m-t-30 f-w-600">PHP<span class="pull-right"><?php echo''.$get_php.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_php.'';?>%; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                            <p class="m-t-30 f-w-600">HTML<span class="pull-right"><?php echo''.$get_html.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_html.'';?>%; height:8px;" class="progress-bar bg-warning wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                            <p class="m-t-30 f-w-600">CSS<span class="pull-right"><?php echo''.$get_css.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_css.'';?>%; height:8px;" class="progress-bar bg-danger wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                            <p class="m-t-30 f-w-600">Photoshop<span class="pull-right"><?php echo''.$get_photoshop.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_photoshop.'';?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                            <p class="m-t-30 f-w-600">Graphics Design<span class="pull-right"><?php echo''.$get_graphic_design.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_graphic_design.'';?>%; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Experience Column end-->
                                                <!--Personal Skill Column Start-->
                                                <!--Experience Column sart-->
                                                  <div class="col-lg-12">
                                                    <div class="card">
                                                        <div class="card-header bg-warning">
                                                            <i class="fa fa-bar-chart f-s-25"></i><strong class="card-title pl-2">Personal Skill</strong>
                                                        </div>
                                                        <div class="card-body browser">
                                                            <br>
                                                            <p class="f-w-600">Team Work <span class="pull-right"><?php echo''.$get_team_work.'';?>%</span></p>
                                                            <div class="progress ">
                                                                <div role="progressbar" style="width: <?php echo''.$get_team_work.'';?>%; height:8px;" class="progress-bar bg-danger wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">Communication<span class="pull-right"><?php echo''.$get_communication.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_communication.'';?>%; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">Leadership<span class="pull-right"><?php echo''.$get_leadership.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_leadership.'';?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">Creativity<span class="pull-right"><?php echo''.$get_creativity.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_creativity.'';?>%; height:8px;" class="progress-bar bg-warning wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>

                                                            <p class="m-t-30 f-w-600">Management<span class="pull-right"><?php echo''.$get_management.'';?>%</span></p>
                                                            <div class="progress m-b-30">
                                                                <div role="progressbar" style="width: <?php echo''.$get_management.'';?>%; height:8px;" class="progress-bar bg-success wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                            <p class="m-t-30 f-w-600">Marketing<span class="pull-right"><?php echo''.$get_marketing.'';?>%</span></p>
                                                            <div class="progress">
                                                                <div role="progressbar" style="width: <?php echo''.$get_marketing.'';?>%; height:8px;" class="progress-bar bg-info wow animated progress-animated"> <span class="sr-only">60% Complete</span> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Personal Skill Column End-->
                                            
                                        </div>
                                    </div>



                                    <!--Describe Info  Column -->
                                    <div class="col-lg-8">
                                        <div class="row">
                                        <!--Personal Info Card-->
                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header bg-primary">
                                                        <i class="fa fa-user-circle-o f-s-25"></i><strong class="card-title pl-2">Personal information</strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="card-two">
                                                            <br>
                                                            <?php if ($get_name!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-user f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_name.'</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>
                                                            <?php if ($get_blood!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-tint f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_blood.'</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>
                                                             <?php if ($get_birthday!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-calendar f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_birthday.'</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>
                                                             <?php if ($get_country!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right"><i class="fa fa-flag f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                    
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <h4 class="text-md-left" style=""> Citizen Of '.$get_country.'</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>

                                                            <?php if ($get_email!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right"><i class="fa fa-envelope f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_email.'</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>
                                                            <?php if ($get_phone!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right"><i class="fa fa-phone f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_phone.'</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>
                                                            <?php if ($get_street!=""&&$get_country!=""&&$get_city!=""&&$get_state!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right"><i class="fa fa-map-marker f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_street.', '.$get_city.', '.$get_state.', '.$get_country.'.</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>
                                                            <?php if ($get_interest_in!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right"><i class="fa fa-coffee f-s-20 color-primary"></i></h4>
                                                                    <hr>
                                                                </div>
                                                                <div class="col-lg-10">
                                                                    <h4 class="text-md-left" style="">'.$get_interest_in.'.</h4>
                                                                   <hr>
                                                                    
                                                                </div>
                                                             
                                                            </div>';?>
                                                            <br>


                                                        </div>
                                                        <hr>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <!--Personal Info End-->

                                            <!--Educational Info Start-->
                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header bg-success">
                                                        <i class="fa fa-graduation-cap f-s-25"></i><strong class="card-title pl-2">Educational Background</strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="card-two">
                                                           <br>
                                                            <?php if ($get_postgraduate_university!=""&&$get_postgraduate_session!=""&&$get_postgraduate_gpa!=""&&$get_postgraduate_degree!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-university f-s-20 color-success"></i></h4>
                                                                    
                                                                </div>
                                                                <div class="col-lg-11">
                                                                    <h4 class="text-md-left text-success" style="">'.$get_postgraduate_degree.'<b class="text-secondary">|'.$get_postgraduate_university.'</b></h4>
                                                                    <h6 class="text-md-left text-secondary" style="">SESSION: <b class="text-secondary">'.$get_postgraduate_session.'</b></h6>
                                                                    <br>
                                                                    <h6 class="text-md-left text-secondary" style="">Result: CGPA <b class="text-secondary">'.$get_postgraduate_gpa.'</b> Out Of <b class="text-secondary">4.0</b> </h6>
                                                                    <hr>
                                                                    <h6 class="text-md-left text-secondary" style="">I have Completed My Post Graduation In <b class="text-secondary">'.$get_postgraduate_degree.'</b> from   <b class="text-secondary">'.$get_postgraduate_university.'</b> in the session <b class="text-secondary">'.$get_postgraduate_session.'</b> and i have got CGPA <b class="text-secondary">'.$get_postgraduate_gpa.'</b> Out Of  <b class="text-secondary">4.0</b> </h6>
                                                                    <hr>
                                                                   
                                                                    
                                                                </div>

                                                             
                                                            </div>';?>

                                                             <br>
                                                            <?php if ($get_undergraduate_university!=""&&$get_undergraduate_session!=""&&$get_undergraduate_gpa!=""&&$get_undergraduate_degree!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-university f-s-20 color-success"></i></h4>
                                                                    
                                                                </div>
                                                                <div class="col-lg-11">
                                                                    <h4 class="text-md-left text-success" style="">'.$get_undergraduate_degree.'<b class="text-secondary">|'.$get_undergraduate_university.'</b></h4>
                                                                    <h6 class="text-md-left text-secondary" style="">SESSION: <b class="text-secondary">'.$get_undergraduate_session.'</b></h6>
                                                                    <br>
                                                                    <h6 class="text-md-left text-secondary" style="">Result: CGPA <b class="text-secondary">'.$get_undergraduate_gpa.'</b> Out Of <b class="text-secondary">4.0</b> </h6>
                                                                    <hr>
                                                                    <h6 class="text-md-left text-secondary" style="">I have Completed My Graduation In <b class="text-secondary">'.$get_undergraduate_degree.'</b> from   <b class="text-secondary">'.$get_undergraduate_university.'</b> in the session <b class="text-secondary">'.$get_undergraduate_session.'</b> and i have got CGPA <b class="text-secondary">'.$get_undergraduate_gpa.'</b> Out Of  <b class="text-secondary">4.0</b> </h6>
                                                                    <hr>
                                                                   
                                                                    
                                                                </div>

                                                             
                                                            </div>';?>
                                                           
                                                             <br>
                                                            <?php if ($get_hsc_school!=""&&$get_hsc_session!=""&&$get_hsc_gpa!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-graduation-cap f-s-20 color-success"></i></h4>
                                                                    
                                                                </div>
                                                                <div class="col-lg-11">
                                                                    <h4 class="text-md-left text-success" style="">H.S.C.<b class="text-secondary">|'.$get_hsc_school.'</b></h4>
                                                                    <h6 class="text-md-left text-secondary" style="">SESSION: <b class="text-secondary">'.$get_hsc_session.'</b></h6>
                                                                    <br>
                                                                    <h6 class="text-md-left text-secondary" style="">Result: GPA <b class="text-secondary">'.$get_hsc_gpa.'</b> Out Of <b class="text-secondary">5.0</b> </h6>
                                                                    <hr>
                                                                    <h6 class="text-md-left text-secondary" style="">I have Completed My Higher Secondary School Certificate Examination from <b class="text-secondary">'.$get_hsc_school.'</b> under the <b class="text-secondary">'.$get_hsc_board.'</b> held in the session <b class="text-secondary">'.$get_hsc_session.'</b> and i have got GPA <b class="text-secondary">'.$get_hsc_gpa.'</b> Out Of  <b class="text-secondary">5.0</b> in the examination. I was in <b class="text-secondary">'.$get_hsc_group.'</b> Group.  </h6>
                                                                    <hr>
                                                                   
                                                                    
                                                                </div>
                                                                
                                                             
                                                            </div>';?>
                                                            <br>
                                                            <?php if ($get_ssc_school!=""&&$get_ssc_session!=""&&$get_ssc_gpa!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-graduation-cap f-s-20 color-success"></i></h4>
                                                                    
                                                                </div>
                                                                <div class="col-lg-11">
                                                                    <h4 class="text-md-left text-success" style="">S.S.C.<b class="text-secondary">|'.$get_ssc_school.'</b></h4>
                                                                    <h6 class="text-md-left text-secondary" style="">SESSION: <b class="text-secondary">'.$get_ssc_session.'</b></h6>
                                                                    <br>
                                                                    <h6 class="text-md-left text-secondary" style="">Result: GPA <b class="text-secondary">'.$get_ssc_gpa.'</b> Out Of <b class="text-secondary">5.0</b> </h6>
                                                                    <hr>
                                                                    <h6 class="text-md-left text-secondary" style="">I have Completed My Secondary School Certificate Examination from <b class="text-secondary">'.$get_ssc_school.'</b> under the <b class="text-secondary">'.$get_ssc_board.'</b> held in the session <b class="text-secondary">'.$get_ssc_session.'</b> and i have got GPA <b class="text-secondary">'.$get_ssc_gpa.'</b> Out Of  <b class="text-secondary">5.0</b> in the examination. I was in <b class="text-secondary">'.$get_ssc_group.'</b> Group. </h6>
                                                                    <hr>
                                                                   
                                                                    
                                                                </div>
                                                                
                                                             
                                                            </div>';?>
                                                       
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--Personal Info End-->
                                            <!--Work Experience Start-->
                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header bg-success">
                                                        <i class="fa fa-black-tie f-s-25"></i><strong class="card-title pl-2">Work Experience</strong>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="card-two">
                                                           <br>
                                                            <?php if ($get_1st_work_place!=""&&$get_1st_designation!=""&&$get_1st_session!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-briefcase f-s-20 color-success"></i></h4>
                                                                    
                                                                </div>
                                                                <div class="col-lg-11">
                                                                    <h4 class="text-md-left text-success" style="">'.$get_1st_designation.'<b class="text-secondary">|'.$get_1st_work_place.'</b></h4>
                                                                    <h6 class="text-md-left text-secondary" style="">SESSION: <b class="text-secondary">'.$get_1st_session.'</b></h6>
                                                                    <br>
                                                                    <h6 class="text-md-left text-secondary" style="">Designation:  <b class="text-secondary">'.$get_1st_designation.'</b> .</h6>
                                                                    <hr>
                                                                    <h6 class="text-md-left text-secondary" style="">I have an job experience in <b class="text-secondary">'.$get_1st_work_place.'</b> from   <b class="text-secondary">'.$get_1st_session.'</b>. in that session I was a very respected <b class="text-secondary">'.$get_1st_designation.'</b> in that institute. and i did my work very sincerely and wholeheartedly.</h6>
                                                                    <hr>
                                                                   
                                                                    
                                                                </div>

                                                             
                                                            </div>';?>
                                                            <br>
                                                            <?php if ($get_2nd_work_place!=""&&$get_2nd_designation!=""&&$get_2nd_session!="") 
                                                            echo'<div class="row">
                                                                <div class="col-lg-1">
                                                                    <h4 class="text-md-right "><i class="fa fa-briefcase f-s-20 color-success"></i></h4>
                                                                    
                                                                </div>
                                                                <div class="col-lg-11">
                                                                    <h4 class="text-md-left text-success" style="">'.$get_2nd_designation.'<b class="text-secondary">|'.$get_2nd_work_place.'</b></h4>
                                                                    <h6 class="text-md-left text-secondary" style="">SESSION: <b class="text-secondary">'.$get_2nd_session.'</b></h6>
                                                                    <br>
                                                                    <h6 class="text-md-left text-secondary" style="">Designation:  <b class="text-secondary">'.$get_2nd_designation.'</b> .</h6>
                                                                    <hr>
                                                                    <h6 class="text-md-left text-secondary" style="">I have an job experience in <b class="text-secondary">'.$get_2nd_work_place.'</b> from   <b class="text-secondary">'.$get_2nd_session.'</b>. in that session I was a very respected <b class="text-secondary">'.$get_2nd_designation.'</b> in that institute. and i did my work very sincerely and wholeheartedly.</h6>
                                                                    <hr>
                                                                   
                                                                    
                                                                </div>

                                                             
                                                            </div>';?>
                                                       
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--Work Experience Start-->
                                            
                                        </div>
                                        


                                    </div>
                                    <!--describe info column end-->

                                    
                                </div>
                                <!--Profile Tab Panel End-->
                            </div>
                            <!--Second Tab Panel End-->
                            <div class="tab-pane" id="settings" role="tabpanel">
                                    <div class="card-body">
                                        <form class="form-horizontal form-material">
                                            <div class="form-group">
                                            <br>
                                                <label class="col-md-12">Your Full Name</label>
                                                <div class="col-md-12">
                                                    <input type="text" placeholder="John Doe" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12">Email</label>
                                                <div class="col-md-12">
                                                    <input type="email" placeholder="Zebra Theme@gmail.com" class="form-control form-control-line" name="example-email" id="example-email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Phone No</label>
                                                <div class="col-md-12">
                                                    <input type="text" placeholder="123 456 7890" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Your Message</label>
                                                <div class="col-md-12">
                                                    <textarea rows="5" class="form-control form-control-line"></textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button class="btn btn-success">Send Message</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                               
                            </div>
                            <!-- all Tab panel End-->
                        </div>
                    </div>
                    <!-- Column -->
                </div>

                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <footer class="footer">Spark-tech-academy © 2018 All rights reserved. designed by <a href="https://sparktechacademy.wordpress.com">SHAMIM HASAN</a></footer>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/prism.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/calendar-2/pignose.init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>

</html>
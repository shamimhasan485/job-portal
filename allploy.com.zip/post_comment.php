 <div class="col-lg-8">
  <?php
$title = $_GET['s_title'];
$p_id = $_GET['id'];

$sql1=mysqli_query($con,"select * from posts where post_id='$p_id'");
                    while($comnt1=mysqli_fetch_array($sql1)){
                           $uid=$comnt1["usr_id_p"];
                        }
                        $sql2=mysqli_query($con,"select * from registration where usr_id='$uid'");
                    while($comnt2=mysqli_fetch_array($sql2)){
                           $im=$comnt2["image"];
                        }
?>   
      
<div class="container">
    <div class="col-sm-8">
        <div class="panel panel-white post panel-shadow">
            <div class="post-heading">
                <div class="pull-left image">
                    <img src="user_images/<?php echo $im; ?>" class="img-circle avatar" alt="user profile image">
                </div>
                <div class="pull-left meta">
                    <div class="title h5">
                        <a href="#"><b></b></a>
                    
                    </div>
                </div>
            </div> 
            <div class="post-description"> 
              
               <?php
$title = $_GET['s_title'];
$p_id = $_GET['id'];

echo $title;

?>
             
   
          
                
            </div>
        	<form action="comment.php" method="post">

            <div class="post-footer">
                <div class="input-group"> 
                    <textarea class="form-control" cols="100" rows="10" placeholder="Add a comment" type="text" name="comment"></textarea>
                    <input class="form-control"  type="hidden" name="uid" value="<?php echo $_SESSION['id']; ?>">
                    <input class="form-control"  type="hidden" name="pid" value="<?php echo $p_id;?>">
                   	<div class="btn-group" role="group" style="margin-top:5px">
					<button type="submit" name="submit_comment"  class="btn btn-primary btn-hover-green" >Post Your Comment</button>
				</div>
                </div>
                </form>
                
                	<?php 
                      $p_id = $_GET['id'];
                      
                     $sql=mysqli_query($con,"select * from comments where post_id_c='$p_id'");
                    while($comnt=mysqli_fetch_array($sql)){
							//fetching all posts
							$time_ago = $comnt['comment_time'];

						echo '
                
                <ul class="comments-list">
                    <li class="comment">
                        <a class="pull-left" href="#">
                            <img class="avatar" src="http://bootdey.com/img/Content/user_1.jpg" alt="avatar">
                        </a>
                        <div class="comment-body">
                            <div class="comment-heading">
                                <h4 class="user">	'.$comnt['name'].'</h4>
                                <h5 class="time">'.timeAgo($time_ago).'</h5>
                            </div>
                            <p>'.$comnt['comment'].'</p>
                        </div>
                       
                    </li>
                
                </ul>
                
                ';	
					}	
				?>
                
            </div>
        </div>
    </div>
</div>
     
     
 </div>